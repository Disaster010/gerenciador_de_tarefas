from flask import Flask, render_template, url_for

app = Flask(__name__)

from projeto_luan import routes

